package t::lib::MyException;
use strict;
use warnings;
use parent 'Exception::Tiny';
1;

